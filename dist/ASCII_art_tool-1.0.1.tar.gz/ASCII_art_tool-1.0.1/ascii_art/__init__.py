# __init__.py

# Version of the ascii_art package
__version__ = "1.0.1"